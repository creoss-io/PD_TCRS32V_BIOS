//##############################################################################
//
//	BIOS BOOTUP
//
//	Modules Name: bios_bu.h
//	Company		: Creoss Inc
//
//----------------------------------------------------------------------
//	[Functional Description]
//
//		- BIOS BU
//
//----------------------------------------------------------------------
//	[Revistion History]
//
//
//##############################################################################

#ifndef		__BIOS_BU_H__
#define		__BIOS_BU_H__



extern	__att_noinline__	enum enum_res_ret	bu_fwld ( uint8_t  ld_opt, uint32_t ld_ef_badd ) ;

#endif	//	__BIOS_BU_H__
