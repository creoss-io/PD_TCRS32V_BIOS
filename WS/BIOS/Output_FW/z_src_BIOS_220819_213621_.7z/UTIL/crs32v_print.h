//======================================================================
// MISC
//======================================================================

#ifndef		__CRS32V_PRINT_H__
#define		__CRS32V_PRINT_H__

#include	<global_include.h>

// print.c
void	print_str(const char *p);
void	print_hex(unsigned int val, int digits);



#endif	//	__CRS32V_PRINT_H__
